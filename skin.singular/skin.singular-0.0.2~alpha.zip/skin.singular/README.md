Singular

skin.singular - by roidy


This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Assets used

Line Awesome font from ICONS8 - https://icons8.com - see /fonts/line-awesome-LICENSE.txt

Montserrat font - see /font/Montserrat-LICENSE.txt

RobotoMono font - see /font/RobotoMono-LICENSE.txt
